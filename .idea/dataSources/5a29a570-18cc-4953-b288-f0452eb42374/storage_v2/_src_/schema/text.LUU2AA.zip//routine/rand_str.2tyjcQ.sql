create function rand_str(size int, type int)
  returns varchar(255)
  begin
    declare seed varchar(255);
    declare seed_no varchar(255) default '1234567890';
    declare seed_en varchar(255) default 'qwertryuiopasdfghjklzxcvbnm';

    declare ret varchar(255) default '';
    declare i int default 0;

    set seed =case type
      when 1 then seed_en
        when 2 then seed_no
      else concat(seed_en,seed_no) end;

    while i < size do
      set ret = concat(ret,substring(seed,floor(length(seed) * rand() +1 ),1));
      set i = i + 1 ;
    end while;
    return ret ;
  end;

