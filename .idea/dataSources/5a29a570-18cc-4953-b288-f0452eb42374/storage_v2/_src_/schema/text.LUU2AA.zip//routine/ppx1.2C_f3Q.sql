create procedure ppx1(IN p int)
  begin
    set @x = 0;
    repeat
    set @x = @x + 1 ;
    until @x > p end repeat ;
  end;

