create procedure pp3(INOUT bbb varchar(30), INOUT ccc varchar(20))
  begin
    insert into t_person (name,weixin) value (bbb,ccc);

    select  count(*) into bbb from t_person;
    select weixin into ccc from t_person limit 1;
  end;

