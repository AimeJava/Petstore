create procedure add_user(IN num int)
  begin
    declare rowid int default 0;
    declare firstname char(1);
    declare name1 char(1);
    declare name2 char(1);
    declare lastname varchar(3) default '';
    declare sex char(1);
    declare score char(2);
    set @exedata = '' ;
    while rowid < num do
      set firstname = substring('赵钱孙李周吴郑王林杨柳刘孙陈江阮侯邹高彭徐', floor(1 + 21 * rand()), 1);
      set name1 = substring('一二三四五六七八九十甲乙丙丁静景京晶名明铭敏闵民军君俊骏天田甜兲恬益依成城诚立莉力黎励', round(1 + 43 * rand()), 1);
      set name2 = substring('一二三四五六七八九十甲乙丙丁静景京晶名明铭敏闵民军君俊骏天田甜兲恬益依成城诚立莉力黎励', round(1 + 43 * rand()), 1);
      set sex = floor(0 + (rand() * 2));
      set score = floor(40+(rand()*60));
      set rowid = rowid+1;
      if round( rand())=0 then
        set lastname = name1;
      end if;
        if round(rand())=1 then
      set lastname = concat(name1,name2);
      end if;
      IF length(@exedata)>0 THEN
        SET @exedata = CONCAT(@exedata,',');
      END IF;
      SET @exedata=concat(@exedata,"('",firstname,"','",lastname,"','",sex,"','",score,"','",rowid,"')");
      IF rowid%1000=0
      THEN
        SET @exesql =concat("insert into user10k(first_name,last_name,sex,score,copy_id) values ", @exedata);
        prepare stmt from @exesql;
        execute stmt;
        DEALLOCATE prepare stmt;
        SET @exedata = "";
      END IF;
    END WHILE;
    IF length(@exedata)>0
    THEN
      SET @exesql =concat("insert into user10k(first_name,last_name,sex,score,copy_id) values ", @exedata);
      prepare stmt from @exesql;
      execute stmt;
      DEALLOCATE prepare stmt;
    END IF;
  END;

